# Bootstrap Mockup Assignment

For this exercise, you will be using your knowledge of HTML and Twitter Bootstrap to code the mockups inside this repository.

Fork/Clone the repo and make a pull request when done.

![](1.png)

![](2.png)

![](3.png)
